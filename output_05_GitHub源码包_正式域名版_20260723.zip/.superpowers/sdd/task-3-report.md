# Task 3 Report: Editable Pet Cost Calculator

## Scope

Implement the Task 3 cost model and cost calculator page in the designated `build-static-site` worktree. The calculator uses editable cat/dog example values only; it does not claim live market prices or provide saving recommendations.

## TDD log

- RED: Added `calculateCost.test.ts`; Vitest failed as expected because `./calculateCost` did not exist.
- GREEN: Added validated pure calculation model and confirmed 7 calculator tests passed.
- RED: Added the editable cat/dog template expectation; Vitest failed as expected because `./defaults` did not exist.
- GREEN: Added cloned cat/dog example templates and confirmed 8 calculator/template tests passed.

## Implementation

- Added `CostInput`/`CostSummary` contracts, including per-item details and required/optional category totals.
- The model rejects every non-finite or negative lifespan/item amount and calculates `firstYear = upfront + monthly * 12 + annual + reserve`.
- Lifetime applies upfront items once and repeats monthly, annual, and reserve costs for the selected lifespan.
- Added a responsive cost page with editable example templates, custom rows, clear form labels, and required/optional breakdowns. It explicitly identifies all template values as examples, with no live-price or saving-advice claims.

## Verification

- `node_modules/.bin/vitest.cmd run --configLoader runner`: 5 files, 28 tests passed.
- `node_modules/.bin/tsc.cmd --noEmit`: passed.
- `node_modules/.bin/vite.cmd --configLoader runner build`: passed; verified all six HTML entry pages in `dist`.

## Commit

`feat: add editable pet cost calculator`

## Self-check

- Cost summary exposes upfront, monthly, annual, reserve, first-year, lifetime, and category details.
- Zero, negative, NaN/Infinity, cadence conversion, lifespan, and custom amounts are covered by tests.
- The cost page is integrated into `App.tsx` and adapts its grids on small screens.

## Concerns

None identified.

## Retrospective

- 成功点：计算规则和编辑模板均有可复跑的 RED/GREEN 证据，且最终全量测试、类型检查与六页构建均通过。
- 失败点：无；缺失计算器与默认模板模块的两次预期 RED 均在最小实现后转绿。
- 优化建议：后续若接入档案功能，可让用户选择将已确认的实际费用写入本地档案；本任务未扩展到该范围。

## Review follow-up

### Root cause and RED/GREEN

- P1 root cause: `CostBreakdown` used `maximumFractionDigits: 0`, so values such as `¥0.50` were rounded to whole yuan. RED: the new `formatCurrency(0.5)` test failed because the pure formatter was not exported. GREEN: exported the formatter and fixed it to two fractional digits; the assertion now returns `¥0.50`.
- P2 root cause: custom rows used `Date.now()`, so additions in one millisecond could receive the same React key/id. RED: the new custom-item test failed because the factory module was absent. GREEN: added a `crypto.randomUUID()`-backed factory, an injectable UUID source, and a monotonic fallback; two fallback calls produce distinct ids.
- P3: renamed the ordinary template helper from `useTemplate` to `templateValues`, making clear it is not a React hook.

### Verification commands and results

- `node_modules/.bin/vitest.cmd run --configLoader runner src/features/cost/costPresentation.test.ts`: 2 tests passed.
- `node_modules/.bin/vitest.cmd run --configLoader runner`: 6 files, 30 tests passed.
- `node_modules/.bin/tsc.cmd --noEmit`: passed.
- `node_modules/.bin/vite.cmd --configLoader runner build`: passed; all six HTML entry pages were present in `dist`.

### Review-fix commit

`fix: preserve cost decimals and unique custom ids`
