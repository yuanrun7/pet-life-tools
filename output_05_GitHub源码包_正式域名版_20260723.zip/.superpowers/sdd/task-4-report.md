# Task 4 Report: Local Records, Migration and Backup

## RED / GREEN

- RED: added `storage.test.ts` and `backup.test.ts`; direct Vitest execution failed because `schema`, `storage`, and `backup` did not yet exist.
- GREEN: implemented a versioned `PetStore`, one namespaced local-storage key, runtime backup validation, and quota handling. The focused suite passed: 2 files, 7 tests.

## Delivered

- `PetStore` version 1 contains pets, health events, expenses, and reminders.
- Pet cards support create, edit, and a second confirmation before deletion.
- Backup download and restore require runtime validation; restore asks before overwriting, and invalid JSON never reaches storage.
- The schedule page stores generated events as health events; the cost page stores the first-year estimate as an expense record.
- The records screen states that data is local-only and does not archive images.

## Verification

- Full test suite: `vitest run --configLoader runner` — 8 files, 37 tests passed.
- TypeScript: `tsc --noEmit` — passed.
- Static build: `vite --configLoader runner build` — passed; produced `index.html` plus `schedule`, `cost`, `lost-pet`, `records`, and `guide` pages.

## Commit

- `feat: add local pet records and backup`

## Self-check

- All external backup data is structurally validated at runtime; no TypeScript assertion is used to trust imported JSON.
- Storage reads recover to an empty store, and writes return a result instead of throwing for quota/unavailable storage.
- A single namespaced key is used. Images are not included in the model or backup.

## Concerns

- Browser-level interaction tests are not present; behavior is covered at storage and backup boundaries.

## NO-GO Fix: Explicit Pet Targets and Referential Validation

### RED / GREEN

- RED: extended `src/features/records/backup.test.ts` with target resolution, impossible-date, and dangling-reference cases. The targeted test command failed before `target.ts` existed with `Cannot find module './target'`.
- GREEN: added `resolvePetTarget()` and strict UTC calendar validation. Backup validation now rejects invalid calendar dates and any health event, expense, or reminder whose `petId` is absent from `pets`.

### Explicit save target

- Schedule and cost pages always show the destination control. With one pet it is visibly selected; with multiple pets no target is preselected; with no pets saving is disabled.
- Both App callbacks accept `petId`, resolve it in the freshly loaded store, and return `false` for unknown identifiers. No save path uses `store.pets[0]`.

### Verification commands and results

- `vitest run --configLoader runner src/features/records/backup.test.ts` — 1 file, 7 tests passed.
- `vitest run --configLoader runner` — 8 files, 40 tests passed.
- `tsc --noEmit` — passed.
- `vite --configLoader runner build` — passed; all six static pages emitted.
