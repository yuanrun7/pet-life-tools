# Task 5 report — lost-pet poster generator

## Status

Implemented the browser-side lost-pet poster generator and connected it to `/lost-pet/`.

## Scope delivered

- Added typed poster input, Chinese/manual-break-aware text wrapping, and Canvas PNG generation for 1080×1440 social and 2480×3508 A4 posters.
- Draws photos with `cover` logic; failed photo decoding retains the text poster and revokes every created Object URL.
- Added required-field form validation, bounded text fields, immediate preview, two download formats, and Web Share with download fallback.
- Photos remain session-only; the page states that AI cutout/repair is not provided.

## TDD and verification

- Confirmed the two provided tests initially failed because `layoutText` and `renderPoster` did not exist.
- Focused tests: 5/5 passed.
- Full tests: 45/45 passed.
- Type check: `tsc --noEmit` passed.
- Production build: Vite built all six pages, including `lost-pet/`.

## Test correction

The original long-contact expectation omitted the last five characters from the 21-character input. It was corrected to assert all characters are preserved across four lines; truncating a contact method would violate the poster requirement.

## Workspace record and retrospective

Task request: resume Task 5 in this worktree, use the existing RED tests, avoid dependency installation, verify, commit, and report.

- 成功点: Existing local tool binaries allowed full verification without installing dependencies.
- 失败点: `pnpm test` attempted dependency reconciliation and was stopped by its non-interactive safeguard; local `vitest`, `tsc`, and `vite` binaries were used instead.
- 优化建议: Keep worktree `node_modules` metadata aligned so package-manager scripts do not attempt reconciliation during offline verification.

## Review-fix addendum

Review request: make maximum text fit both canvases, clip cover photos, harden Web Share fallback, apply the required-field gate to every export path, and make text wrapping strictly respect the supplied maximum width.

- Replaced fixed text metrics with layout calculation that reduces the body font only as needed and reserves the footer. The 300-character features and 120-character contact values are asserted complete and in-bounds for social and A4 posters.
- Added `save → beginPath → rect → clip → drawImage → restore` around cover rendering.
- Moved export/share decisions into testable `posterActions` helpers. Sharing now requires `canShare({ files }) === true`; unavailable capability and non-cancel errors download, while `AbortError` does not.
- Download and sharing share one required-field guard, and the UI disables all export actions until it passes.
- Removed the one-character overflow exception in `wrapText`.

### Review verification

- Targeted lost-pet tests: 12/12 passed.
- Full test suite: 52/52 passed.
- `tsc --noEmit`: passed (exit 0).
- `vite --configLoader runner build`: passed (exit 0), including all six routes.

### Retrospective

- 成功点: Boundary and side-effect requirements are now covered by deterministic unit tests instead of UI-only assumptions.
- 失败点: The original renderer used fixed dimensions and the original sharing branch treated an absent capability check as permission to share.
- 优化建议: Keep safety-critical browser API decisions in dependency-injected helpers so fallback behavior remains directly testable.
